<?php
// echoing the footer
echo '<footer>
<div class="fmiddle">
    <h4>SMT Movie Rentals</h4>
    Thank you for using SMT Movie Rentals
</div>
</footer>';
?>