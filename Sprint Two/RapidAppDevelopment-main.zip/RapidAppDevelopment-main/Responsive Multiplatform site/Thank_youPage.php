<!DOCTYPE html>
<html lang = "en">

    <?php
            
    ?>

    <head>
        <title>Membership Management</title>
        <meta charset="UTF-8">
        
        <link rel="stylesheet" href="main4.css">
    </head > 

    <Body >
        <?php 
    include_once ('include/nav.php');
    ?>
    
    <div class="wrapper">   
        <div class="contact-form">
            <div class="input-fields">
            

                <h1 class="pink" > 🎉 Thank you for your subscription! 🎉  </h1>
                <br>
                <input type="submit" name="submit" value="Back To Home" class="button" onclick="location.href = 'index.php';" />

                

                 
                                    
                                                     
                </Form>
                <br>               
            </div>
            
            
        </div>
        
    </div>

    <?php
    
    include_once ('include/footer.php');

    ?>
            
    </Body>
   
</html>








