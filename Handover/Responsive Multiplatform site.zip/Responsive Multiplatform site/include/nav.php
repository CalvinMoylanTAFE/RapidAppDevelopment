<?php 
// echoing the nav bar
echo '<nav>

<!-- <li><img height="50px" src="websitelogo.png" ></li> -->
<li><a href="index.php">HOME</a></li>
<li><a href="search_movie.php">SEARCH</a></li>
<li><a href="add_movie.php">ADD</a></li>
<li><a href="Addsub.php">SUBSCRIPTION</a></li>
<li><a href="MovieRatings.php">RATE A MOVIE</a></li>
<li><a href="Graphs.php">COMPARISON CHARTS</a></li>

</nav>';
?>