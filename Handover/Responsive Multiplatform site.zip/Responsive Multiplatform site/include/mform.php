<?php
// echoing the search form
echo '<div class="middle">
<h1>Rate movie Form</h1>
<p>Select below</p>
<form action="MovieRatings.php" method="POST">
  </form>
</div>';
?>