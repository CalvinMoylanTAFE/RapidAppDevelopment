<!DOCTYPE html>
<head>
        <!-- Linking stylesheet and the font -->
        <title>SMT Movie Rentals</title>
        <link rel="stylesheet" href="styles.css">
        <link href="https://fonts.googleapis.com/css?family=Rajdhani:300,500,700&display=swap" rel="stylesheet">
    </head>
<html>
    <body style="background-size: cover;">
        <!-- include nav  -->
        <?php
            include_once ('include/nav.php');
        ?>
        <main>
        </main>
        
    </body>
</html>
